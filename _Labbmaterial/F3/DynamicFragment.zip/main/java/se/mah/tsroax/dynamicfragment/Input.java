package se.mah.tsroax.dynamicfragment;

public interface Input {
	public void setController(Controller controller);
	public void enableChoiceButtons(boolean enabled);
}
