package se.mah.da117a.prefs;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;


public class MyActivity extends Activity {


  EditText myTodo;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_my);

    myTodo = (EditText) findViewById(R.id.todo);
  }

  @Override
  protected void onResume() {
    super.onResume();

    SharedPreferences preferences = getSharedPreferences("mytodoprefs", Context.MODE_PRIVATE);
    if( preferences.contains("mytodo") )
      myTodo.setText(preferences.getString("mytodo", ""));

  }

  @Override
  protected void onPause() {
    super.onPause();

    SharedPreferences preferences = getSharedPreferences("mytodoprefs", Context.MODE_PRIVATE);
    SharedPreferences.Editor editor = preferences.edit();

    String todo = myTodo.getText().toString();
    if (todo != null && todo.length() > 0)
      editor.putString("mytodo", todo);
    else
      editor.remove("mytodo");

    editor.commit();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.my, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    int id = item.getItemId();
    if (id == R.id.action_settings) {
      return true;
    }
    return super.onOptionsItemSelected(item);
  }
}
