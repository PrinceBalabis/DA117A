package se.mah.tsroax.rpsstaticfragment;

import android.app.Fragment;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

public class ViewerFragment extends Fragment {
	private TextView tvHumanPoints;
	private TextView tvComputerPoints;
	private ImageView ivHumanChoice;
	private ImageView ivComputerChoice;
	private Drawable winner, loser;
	private Drawable[] humanImages = new Drawable[4];
	private Drawable[] computerImages = new Drawable[4];

    @Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View view =  inflater.inflate(R.layout.viewer, container, false);
		initializeComponents(view);
		initializeResources();
		return view;
	}

	private void initializeComponents(View view) {
		tvHumanPoints = (TextView)view.findViewById(R.id.tvHumanPoints);
		tvComputerPoints = (TextView)view.findViewById(R.id.tvComputerPoints);
		ivHumanChoice = (ImageView)view.findViewById(R.id.ivHumanChoice);
		ivComputerChoice = (ImageView)view.findViewById(R.id.ivComputerChoice);
	}

	private void initializeResources() {
		Resources res = getResources();
		Drawable empty = res.getDrawable(R.drawable.empty);
		humanImages[RPSController.ROCK] = res.getDrawable(R.drawable.rockleft);
		humanImages[RPSController.PAPER] = res.getDrawable(R.drawable.paperleft);
		humanImages[RPSController.SCISSORS] = res.getDrawable(R.drawable.scissorsleft);
		humanImages[RPSController.EMPTY] = empty;
		computerImages[RPSController.ROCK] = res.getDrawable(R.drawable.rockright);
		computerImages[RPSController.PAPER] = res.getDrawable(R.drawable.paperright);
		computerImages[RPSController.SCISSORS] = res.getDrawable(R.drawable.scissorsright);
		computerImages[RPSController.EMPTY] = empty;
		winner = res.getDrawable(R.drawable.winner);
		loser = res.getDrawable(R.drawable.loser);
	}
	
	public void setHumanPoints(int points) {
        tvHumanPoints.setText(String.valueOf(points));
	}

	public void setComputerPoints(int points) {
		tvComputerPoints.setText(String.valueOf(points));
	}
	
	public void setHumanChoice(int choice) {
		ivHumanChoice.setImageDrawable(humanImages[choice]);
	}
	
	public void setComputerChoice(int choice) {
		ivComputerChoice.setImageDrawable(computerImages[choice]);
	}
	
	public void humanWinner() {
		LayerDrawable theWinner = new LayerDrawable(new Drawable[]{ivHumanChoice.getDrawable(),winner});
		LayerDrawable theLoser = new LayerDrawable(new Drawable[]{ivComputerChoice.getDrawable(),loser});		
		ivHumanChoice.setImageDrawable(theWinner);
		ivComputerChoice.setImageDrawable(theLoser);
	}
	
	public void computerWinner() {
		LayerDrawable theWinner = new LayerDrawable(new Drawable[]{ivComputerChoice.getDrawable(),winner});
		LayerDrawable theLoser = new LayerDrawable(new Drawable[]{ivHumanChoice.getDrawable(),loser});		
		ivComputerChoice.setImageDrawable(theWinner);
		ivHumanChoice.setImageDrawable(theLoser);
	}

}
