package se.mah.tsroax.rpsstaticfragment;

import java.util.Random;

public class RPSPlayer {
	private Random random = new Random();
	public int nextChoice() {
		int choice = RPSController.ROCK;
		switch(random.nextInt(3)) {
		    case 0: choice = RPSController.PAPER; break;
		    case 1: choice = RPSController.SCISSORS; break;
		}
		return choice;
	}
}
